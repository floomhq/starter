# Claude Skill Page Handoff

Open `index.html` first.

This bundle is a standalone copy of Floom's skills page. It is intentionally
named `index.html` because Claude and preview tools often expect that entry
point.

## Included Files

- `index.html` - the skills page to review or edit.
- `floom-pages.css` - shared page styles required by `index.html`.
- `assets/floom-starter-skills.zip` - the downloadable skills pack used by the
  page CTAs.

## What To Preserve

- Download-first v0 positioning.
- No auto-sync promise.
- Focused skills pack language.
- The Swiss/SaaS visual style from the existing page.

## Suggested Prompt

Improve this standalone Floom skills page. Use `index.html` as the source of
truth. Keep the page focused on downloading a starter skills pack and do not
introduce an auto-sync launch promise.
